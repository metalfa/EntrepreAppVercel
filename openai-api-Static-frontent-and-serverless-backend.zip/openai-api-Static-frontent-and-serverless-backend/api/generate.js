const express = require('express');
const axios = require('axios');
const cors = require('cors'); // Import the cors package

const app = express();
app.use(express.json());
app.use(cors()); // Enable CORS for all routes

const port = process.env.PORT || 3000;

app.post('/api/generate', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).send({ error: 'Prompt is required' });
    }

    try {
        const response = await axios.post(
            'https://api.openai.com/v1/completions',
            {
                model: 'gpt-3.5-turbo-instruct',
                prompt: prompt,
                max_tokens: 100,
            },
            {
                headers: {
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
                },
            }
        );

        res.send({ text: response.data.choices[0].text });
    } catch (error) {
        console.error('Error generating content:', error.response ? error.response.data : error.message);
        res.status(500).send({ error: 'Error generating content', details: error.response ? error.response.data : error.message });
    }
});

module.exports = app;

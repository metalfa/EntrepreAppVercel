const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path');

// Explicitly load the .env file from the root directory
const envPath = path.resolve(__dirname, './.env');
console.log('Loading .env file from:', envPath);
dotenv.config({ path: envPath });

// Log the loaded API key to ensure it's correct
console.log('Loaded API Key before setting:', process.env.OPENAI_API_KEY);

// Manually override the environment variable for testing
process.env.OPENAI_API_KEY = process.env.OPENAI_API_KEY;
console.log('Loaded API Key after setting:', process.env.OPENAI_API_KEY);

async function testAPI() {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/completions',
            {
                model: 'gpt-3.5-turbo-instruct', // Ensure correct model
                prompt: 'Say something nice',
                max_tokens: 10,
            },
            {
                headers: {
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
                },
            }
        );
        console.log(response.data);
    } catch (error) {
        console.error('Error:', error.response ? error.response.data : error.message);
    }
}

testAPI();

const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path');

// Explicitly load the .env file from the root directory
const envPath = path.resolve(__dirname, './.env');
console.log('Loading .env file from:', envPath);
dotenv.config({ path: envPath });

// Manually override the environment variable for testing
process.env.OPENAI_API_KEY = 'sk-proj-ySV281rhwgM0jVixSMLCT3BlbkFJinFfx1BWGHyShSkNOYz2';
console.log('Loaded API Key:', process.env.OPENAI_API_KEY);

async function testAPI() {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/completions',
            {
                model: 'text-curie-001', // Use text-curie-001 model
                prompt: 'Say something nice',
                max_tokens: 10,
            },
            {
                headers: {
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
                },
            }
        );
        console.log(response.data);
    } catch (error) {
        console.error('Error:', error.response ? error.response.data : error.message);
    }
}

testAPI();
